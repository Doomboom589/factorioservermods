data:extend{
	--Custom hotkeys
    {
        type = "custom-input",
        name = "fill4me-keybind-reload",
        key_sequence = "CONTROL + R",
        consuming = "game-only",
    },
    {
        type = "custom-input",
        name = "fill4me-keybind-enable",
        key_sequence = "CONTROL + SHIFT + R",
        consuming = "none",
    },
}