require("framework"){

	scripts = { -- custom scripts

		"metatables",
		"util",
		"helpers",	
		"setup",
		"visuals",
		"drag",
		"cleanup",

	},

	inputs = {  -- custom inputs

		"inventory-cleanup", -- SHIFT + C

	}
	
}