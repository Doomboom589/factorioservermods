local Constants = {}

Constants.ModName = "inbuilt_lighting"
Constants.AssetModName = "__" .. Constants.ModName .. "__"

return Constants
