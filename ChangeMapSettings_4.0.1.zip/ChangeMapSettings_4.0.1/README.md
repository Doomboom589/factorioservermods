# ChangeMapSettings

Allows you to change your map and map generation settings at any time you want. Note that map generation changes only apply to new chunks.
